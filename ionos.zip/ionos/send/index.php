<?php
error_reporting(0);