<?php
$yourmail  = "futufutu96@gmail.com";  // PUT YOUR E-MAIL HERE
$Chat_Id   = "";  // TYPE YOUR CHAT ID.
$Telegram_Bot_Token  = ""; // TYPE YOUR BOT TOKEN.
?>